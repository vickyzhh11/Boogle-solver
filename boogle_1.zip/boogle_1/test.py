import time

# --- function from boogle 0---
def possibleMoves(position, board):
    x, y = position
    moves = []
    n = len(board)
    for dx in [-1, 0, 1]:
        for dy in [-1, 0, 1]:
            if dx == 0 and dy == 0: continue
            newx, newy = x + dx, y + dy
            if 0 <= newx < n and 0 <= newy < n:
                moves.append((newx, newy))
    return moves

# --- boogle 1 ---

def legalMoves(moves, path):
    # Retorna movimientos que no estén ya en el camino actual
    return set(moves) - set(path)

def readDictionary(filename):
    words = []
    try:
        with open(filename, "r") as file:
            for line in file:
                word = line.strip().upper() # Importante: Todo a mayúsculas
                if word:
                    words.append(word)
    except FileNotFoundError:
        print(f"Error: No se encontró el archivo {filename}")
    return words

def examineState(board, position, path, myDict):
    # 1. Crear el nuevo camino incluyendo la posición actual
    current_path = list(path) + [position]
    
    # 2. Construir la palabra extrayendo letras del tablero
    word = "".join([board[r][c] for r, c in current_path]).upper()
    
    # 3. Verificar si la palabra está en el diccionario (set para velocidad)
    if word in myDict:
        return (word, "Yes")
    else:
        return (word, "No")

def runBoard(board_filename, dictionary_filename):
    # Cargar tablero
    board = []
    with open(board_filename, "r") as f:
        for line in f:
            row = line.strip().split()
            if row: 
                board.append(row)
                print(" ".join(row))

    # Cargar diccionario y convertir a SET para búsqueda instantánea
    # (Buscando en una lista normal, el proceso tardaría horas)
    full_dict = set(readDictionary(dictionary_filename))
    
    print("\nAnd we're off!")
    print("Running with cleverness  OFF")
    
    start_time = time.time()
    total_moves = 0
    found_words = set()
    
    # Tamaño del tablero
    n = len(board)
    
    # Para cada celda del tablero, iniciar una búsqueda
    for r in range(n):
        for c in range(n):
            # Stack para DFS: (posición_actual, camino_recorrido)
            stack = [((r, c), ())]
            
            while stack:
                pos, path = stack.pop()
                total_moves += 1
                
                word, valid = examineState(board, pos, path, full_dict)
                
                if valid == "Yes" and len(word) >= 2: # Boggle suele pedir min 2 o 3 letras
                    found_words.add(word)
                
                # Limitar profundidad para evitar explosión combinatoria en Part 1
                # (board5 es pequeño, pero sin poda, caminos de 16 letras son billones)
                if len(path) < 7: 
                    new_path = path + (pos,)
                    moves = possibleMoves(pos, board)
                    for next_move in legalMoves(moves, new_path):
                        stack.append((next_move, new_path))
                        
    end_time = time.time()
    print("\nAll done")
    print(f"Searched total of {total_moves} moves in {round(end_time - start_time, 3)} seconds")

    # Mostrar resultados agrupados
    words_by_len = {}
    for w in found_words:
        words_by_len.setdefault(len(w), []).append(w)
        
    print("\nWords found:")
    for length in sorted(words_by_len.keys()):
        print(f"{length} -letter words: {', '.join(sorted(words_by_len[length]))}")

    print(f"\nFound {len(found_words)} words in total.")
    print("Alpha-sorted list words:")
    print(", ".join(sorted(found_words)))
    
#runBoard("board2.txt", "twl06.txt")
#runBoard("board3.txt", "twl06.txt")
runBoard("board4.txt", "twl06.txt")
