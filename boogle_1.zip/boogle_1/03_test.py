# ---------- PART 0 ---------- 
def possibleMoves(position, board):
    # calculates and returns the positions from a given position 
    x, y = position
    moves = []
    n = len(board)

    for dx in [-1, 0, 1]:
        for dy in [-1, 0, 1]:
            if dx == 0 and dy == 0:
                continue
            newx, newy = x + dx, y + dy
            if 0 <= newx < n and 0 <= newy < n:
                moves.append((newx, newy))
    return moves

# ---------- PART 1 ----------
def legalMoves(moves, path):
    """
    Remove illegal moves that revisit titles already used in the current path
    """ 
    return set(moves) - set(path)

def readDictionary(filename):
    """
    Loads the dictionaty file into Python
    """
    words = []
    with open(filename, "r") as file:
        for line in file:
            word = line.strip()
            if word != "":
                words.append(word.upper())
    return words

def examineState(board, position, path, myDict):
    """
    Extends the path, builds the word from the board, and checks if it exists in the dictionary
    """
    new_path = list(path) + [position] #Extend the path
    
    word = "" # Build word from board
    for (row, col) in new_path:
        word += board[row][col].upper()
    
    # Dictionary check in uppercase
    if word.upper() in myDict:
        return (word, "Yes")
    else:
        return (word, "No")

import time 
def runBoard(board_filename, dictionary_filename):
    """
    Runs the full Boggle solver and prints formatted results.
    """
    # Load the board
    board = []
    with open(board_filename, "r") as file:
        for line in file:
            board.append(line.strip().split())
    
    # Load dictionary
    myDict = set(readDictionary(dictionary_filename))
    
    # Print the board
    for row in board:
        print("".join(row))
    print("\nAnd we're off!")
    print("Running with cleverness ON")
    
    start_time = time.time()
    
    total_moves = 0
    found_words = set()
    
    # Explore the board
    for r in range(len(board)):
        for c in range(len(board)):
            stack = [((r, c), ())]
            
            while stack:
                position, path = stack.pop()
                
                word, valid = examineState(board, position, path, myDict)
                total_moves += 1
                
                if valid == "Yes":
                    found_words.add(word.upper())
                
                # Extend path and continue exploration
                new_path = path + (position, )
                moves = possibleMoves(position, board)
                legal = legalMoves(moves, new_path)
                
                for move in legal:
                    if len(new_path) < 7:
                        stack.append((move, new_path))
                    
    end_time = time.time()
    
    print("\nAll done\n")
    print(f"Searched total of {total_moves} moves in  {round(end_time - start_time, 3)} seconds\n")

    # Group words by length
    words_by_length = {}
    for word in found_words:
        words_by_length.setdefault(len(word), []).append(word)

    print("Words found:")
    total_words = 0
    for length in sorted(words_by_length):
        words = sorted(words_by_length[length])
        total_words += len(words)
        print(f"{length} -letter words:  {', '.join(words)}")

    print(f"\nFound  {total_words}  words in total. ")
    print("Alpha-sorted list words:")
    print(", ".join(sorted(found_words)))    
    
#runBoard("board2.txt", "twl06.txt")
#runBoard("board3.txt", "twl06.txt")
runBoard("board4.txt", "twl06.txt")
